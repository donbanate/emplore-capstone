CREATE DATABASE IF NOT EXISTS `emplore`;

DROP TABLE IF EXISTS `approvals`;

CREATE TABLE `approvals` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `remark_type` varchar(50) NOT NULL,
  `comment` varchar(300) NOT NULL,
  `approved_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `approvals` VALUES("1","unchecked","","2017-12-23 19:15:58","38");
INSERT INTO `approvals` VALUES("2","Approved","","2017-12-23 20:35:27","38");
INSERT INTO `approvals` VALUES("3","Disapproved","HMMMM","2017-12-23 20:31:04","38");
INSERT INTO `approvals` VALUES("4","unchecked","","2017-12-23 19:18:21","38");
INSERT INTO `approvals` VALUES("5","unchecked","","2017-12-23 19:21:22","28");
INSERT INTO `approvals` VALUES("6","Canceled","Awwwwtsu","2017-12-23 20:31:19","28");
INSERT INTO `approvals` VALUES("7","Approved","","2017-12-24 12:35:15","28");
INSERT INTO `approvals` VALUES("8","unchecked","","2017-12-24 16:29:50","28");
INSERT INTO `approvals` VALUES("9","unchecked","","2017-12-24 16:33:58","28");
INSERT INTO `approvals` VALUES("10","unchecked","","2017-12-24 16:36:48","28");
INSERT INTO `approvals` VALUES("11","unchecked","","2017-12-24 16:38:32","28");
INSERT INTO `approvals` VALUES("12","unchecked","","2017-12-24 16:41:02","38");
INSERT INTO `approvals` VALUES("13","unchecked","","2017-12-24 16:42:23","38");
INSERT INTO `approvals` VALUES("14","Rescheduled","Your training is rescheduled","2018-01-11 10:41:49","38");
INSERT INTO `approvals` VALUES("15","unchecked","","2017-12-25 13:09:07","39");
INSERT INTO `approvals` VALUES("16","unchecked","","2017-12-26 19:14:06","40");
INSERT INTO `approvals` VALUES("17","Rescheduled","Your training was rescheduled\n","2018-01-10 13:33:46","42");
INSERT INTO `approvals` VALUES("18","Approved","","2018-01-10 13:38:39","42");
INSERT INTO `approvals` VALUES("19","Rescheduled","Your Seminar is Posponed","2018-01-10 16:01:23","43");
INSERT INTO `approvals` VALUES("20","Approved","","2018-01-10 16:06:09","43");
INSERT INTO `approvals` VALUES("21","Rescheduled","Your training is rescheduled","2018-01-11 10:42:31","45");



DROP TABLE IF EXISTS `employee_designations`;

CREATE TABLE `employee_designations` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `designated_as` varchar(50) NOT NULL,
  `department` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `employee_designations` VALUES("1","Extension Coordinator","N/A");
INSERT INTO `employee_designations` VALUES("2","Extension Coordinator","N/A");
INSERT INTO `employee_designations` VALUES("3","Extension Coordinator","N/A");
INSERT INTO `employee_designations` VALUES("28","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("29","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("30","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("31","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("32","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("33","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("34","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("35","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("36","Extension Coordinator","College of Agriculture");
INSERT INTO `employee_designations` VALUES("37","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("38","Extension Coordinator","College of Busines Entrepreneurship and Accountancy");
INSERT INTO `employee_designations` VALUES("39","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("40","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("41","Extension Coordinator","College of Busines Entrepreneurship and Accountancy");
INSERT INTO `employee_designations` VALUES("42","Extension Coordinator","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("43","Associate Dean","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("44","requested","College of Infomation and Computing Sciences");
INSERT INTO `employee_designations` VALUES("45","Associate Dean","College of Infomation and Computing Sciences");



DROP TABLE IF EXISTS `employee_training_needs`;

CREATE TABLE `employee_training_needs` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `transportation_expense` int(11) NOT NULL,
  `total_cost_of_per_diem` int(11) NOT NULL,
  `seminar_training_fee` int(150) NOT NULL,
  `total_expenses_to_be_incurred` int(150) NOT NULL,
  `training_title` varchar(150) NOT NULL,
  `is_fund_available` tinyint(1) NOT NULL DEFAULT '0',
  `is_in_training_needs` tinyint(1) NOT NULL DEFAULT '0',
  `remark` varchar(150) NOT NULL,
  `final_remark` varchar(30) NOT NULL DEFAULT 'unchecked',
  `reasons` varchar(150) NOT NULL,
  `date_checked` datetime NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `employee_training_needs` VALUES("1","100","100","100","300","Test","0","1","checked","disapproved","Ssdfsaf","2017-12-23 07:41:05","38");
INSERT INTO `employee_training_needs` VALUES("2","100","101","105","306","Y4it","1","1","checked","Approved by the admin"," ","2017-12-23 08:35:11","38");
INSERT INTO `employee_training_needs` VALUES("3","100","100564","5454","106118","Laravel","1","1","checked","Disapproved by the admin"," ","2017-12-23 07:38:12","38");
INSERT INTO `employee_training_needs` VALUES("4","100","10065","351","10516","Bootstrap Css","0","1","checked","disapproved","GAGA","2017-12-23 07:47:09","38");
INSERT INTO `employee_training_needs` VALUES("5","1005","361","654","2020","Networking","0","1","checked","disapproved","Hmmm","2017-12-23 07:38:29","28");
INSERT INTO `employee_training_needs` VALUES("6","1005","641","123","1769","Laravel","1","1","checked","Canceled by the admin"," ","2017-12-23 07:25:57","28");
INSERT INTO `employee_training_needs` VALUES("7","165","957","153","1275","Toottip Test","1","1","checked","Approved by the admin"," ","2017-12-24 12:23:12","28");
INSERT INTO `employee_training_needs` VALUES("8","513","651","416","1580","Y4it","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","28");
INSERT INTO `employee_training_needs` VALUES("9","100","1005","656","1761","How To Write The Perfect Headline","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","28");
INSERT INTO `employee_training_needs` VALUES("10","646","616","96461","97723","10 Best Practices For Seminar","0","1","unchecked","checked by the fsd"," ","0000-00-00 00:00:00","28");
INSERT INTO `employee_training_needs` VALUES("11","6421","563","4661","11645","Raw Poseidon","0","1","checked","disapproved","Hmmm","2017-12-24 05:04:56","28");
INSERT INTO `employee_training_needs` VALUES("12","165","651","669","1485","7 Easy Ways To Make Seminar Faster","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","38");
INSERT INTO `employee_training_needs` VALUES("13","1616","663","6165","8444","Marriage And Semianar Have More In Common Than You Think","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","38");
INSERT INTO `employee_training_needs` VALUES("14","100","65645","65463","131208","Why Some People Almost Always Make/save Money With Semianar","1","1","checked","Approved by the admin"," ","2017-12-24 04:56:41","38");
INSERT INTO `employee_training_needs` VALUES("15","100","100","100","300","Programming","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","39");
INSERT INTO `employee_training_needs` VALUES("16","100","100","100","300","Y4it","0","0","unchecked","unchecked"," ","0000-00-00 00:00:00","40");
INSERT INTO `employee_training_needs` VALUES("17","2000","1000","2000","5000","Mobile App","1","1","checked","Approved by the admin"," ","2018-01-10 01:31:32","42");
INSERT INTO `employee_training_needs` VALUES("18","2000","1000","2000","5000","Mobile App","1","1","checked","Approved by the admin"," ","2018-01-10 01:38:13","42");
INSERT INTO `employee_training_needs` VALUES("19","2000","2000","200","4200","Multimedia Seminar","1","1","checked","Approved by the admin"," ","2018-01-10 03:59:52","43");
INSERT INTO `employee_training_needs` VALUES("20","2000","2000","200","4200","Multimedia Seminar","1","1","checked","Approved by the admin"," ","2018-01-10 04:05:38","43");
INSERT INTO `employee_training_needs` VALUES("21","100","100","561","761","Embeded System","1","1","checked","Approved by the admin"," ","2018-01-11 10:40:12","45");



DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `name_extension` varchar(150) NOT NULL,
  `sex` varchar(150) NOT NULL,
  `age` varchar(150) NOT NULL,
  `birth_date` varchar(150) NOT NULL,
  `birth_place` varchar(150) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `image` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `employees` VALUES("1","admin","admin","admin","admin","N/A","N/A","N/A","N/A","N/A","N/A","N/A","");
INSERT INTO `employees` VALUES("2","accounting","accounting","accounting","accounting","N/A","N/A","N/A","N/A","N/A","N/A","N/A","");
INSERT INTO `employees` VALUES("3","fsd_coordinator","fsd_coordinator","fsd_coordinator","fsd_coordinator","N/A","N/A","N/A","N/A","N/A","N/A","N/A","");
INSERT INTO `employees` VALUES("28","Lyndon","Palor","Banate","Jr.","Male","64","12/14/1953","Sta. Teresita Cagayan","Tagay","San Juanico","09121231234","");
INSERT INTO `employees` VALUES("29","Elmarie","Dela","Suetos","","Male","30","07/15/1987","Gonzaga","Smart","Gonzaga Cagayan Valley","09751162769","");
INSERT INTO `employees` VALUES("30","Elmarie","Suetos","Suetos","","Female","-1","12/20/2017","Gonzaga Cagayan","Flourishing","Gonzaga Cagayan Valley","09564312432","");
INSERT INTO `employees` VALUES("31","Richard","Ramirez","Ayuyang","","Male","23","05/16/1994","Gonzaga Cagayan","Paradise","Gonzaga Cagayan Valley","09675423541","");
INSERT INTO `employees` VALUES("32","Dorothy","Ramirez","Ayuyang","","Female","64","12/14/1953","Gonzaga Cagayan","Paradise","Gonzaga Cagayan Valley","09453212431","");
INSERT INTO `employees` VALUES("33","Clyde Charl","Baclig","Alibania","","Male","64","12/14/1953","Gonzaga Cagayan","Flourishing","Gonzaga Cagayan Valley","09564312432","");
INSERT INTO `employees` VALUES("34","Verdict","Banate","Gonsalez","","Male","74","12/13/1943","Sta. Teresita Cagayan","Buyun","Sta. Teresita Cagayan Valley","09564312431","");
INSERT INTO `employees` VALUES("35","Charlot","Reyes","Maramag","","Female","64","12/14/1953","Gonzaga Cagayan","Paradise","Gonzaga Cagayan Valley","09564312761","");
INSERT INTO `employees` VALUES("36","Juan","Dela","Hoya","","Male","28","06/14/1989","Gonzaga Cagayan","Flourishing","Gonzaga Cagayan Valley","09751192281","");
INSERT INTO `employees` VALUES("37","Dorothy","Maramag","Ayuyang","","Female","41","02/14/1976","Santo Nino, Cagayan","Progressive","Gonzaga Cagayan Valley","09177925717","");
INSERT INTO `employees` VALUES("38","Test","Tempo","Debugging","Jr.","Female","0","12/05/2017","Hmmm","Test Temporary","Sta. Teresita Cagayan Valley","09121231234","");
INSERT INTO `employees` VALUES("39","Richard","Ramirez","Ayuyang","","Male","20","01/04/1997","Gonzaga","Progresive","Gonzaga Cagayan Valley","09674312431","");
INSERT INTO `employees` VALUES("40","Noli","Blancas","Oandasan","","Male","21","01/04/1996","Sta. Teresita Cagayan","Masi","Sta. Teresita Cagayan Valley","09758829277","");
INSERT INTO `employees` VALUES("41","Arnold","Pajarillo","Arquero","","Male","24","01/20/1993","Sta. Teresita Cagayan","Centro West","Sta. Teresita Cagayan Valley","09882273661","");
INSERT INTO `employees` VALUES("42","Clyden charl","Baclig","Alibania","","Male","36","03/03/1981","Gonzaga, Cagayan","Progressive","Gonzaga Cagayan Valley","09171234567","");
INSERT INTO `employees` VALUES("43","Charlot","Lagutan","Maramag","","Female","27","09/11/1990","Sto. Nino Cagayan","Progressive","Gonzaga Cagayan Valley","09350923118","");
INSERT INTO `employees` VALUES("44","Noli","Blancas","Oandasan","","Male","22","01/04/1996","Gonzaga Cagayan","Masi","Sta. Teresita Cagayan Valley","09758822711","");
INSERT INTO `employees` VALUES("45","Richard","Ramirez","Ayuyang","","Male","2017","1976-05-17","Gonzaga","Progressive","Gonzaga Cagayan Valley","09121231234","");



DROP TABLE IF EXISTS `expected_trainings`;

CREATE TABLE `expected_trainings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_title` varchar(300) NOT NULL,
  `expected_date` varchar(20) NOT NULL,
  `expected_expenses` varchar(10) NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `expected_trainings` VALUES("1","How To Be A Good Teammate","2018-01-25","21456","28");
INSERT INTO `expected_trainings` VALUES("2","How to become responsible member","2018-01-25","561","28");
INSERT INTO `expected_trainings` VALUES("3","Hello","2017-12-22","56516","28");
INSERT INTO `expected_trainings` VALUES("4","Linux Administration","2018-01-25","1000","45");



DROP TABLE IF EXISTS `iteneraries`;

CREATE TABLE `iteneraries` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `venue` varchar(150) NOT NULL,
  `date_departure` varchar(150) NOT NULL,
  `date_arrival` varchar(150) NOT NULL,
  `transportation` varchar(150) NOT NULL,
  `expenses` varchar(150) NOT NULL,
  `total` mediumint(150) NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `iteneraries` VALUES("1","Csu-gonzaga","2018-11-24","2018-12-25","100","100","200","38");
INSERT INTO `iteneraries` VALUES("2","Csu-gonzaga","2018-11-24","2019-12-26","65465","65654","131119","38");
INSERT INTO `iteneraries` VALUES("3","Csu-gonzaga","2019-10-25","2021-11-27","100","1005","1105","38");
INSERT INTO `iteneraries` VALUES("4","Csu-gonzaga","2018-11-24","2019-12-26","651","658","1309","38");
INSERT INTO `iteneraries` VALUES("5","Csu Aparri","2018-01-24","2019-02-25","535","3156","3691","28");
INSERT INTO `iteneraries` VALUES("6","Csu-gonzaga","2018-12-24","2019-01-25","1006","651","1657","28");
INSERT INTO `iteneraries` VALUES("7","Test","2018-01-25","2019-01-26","100","100","200","28");
INSERT INTO `iteneraries` VALUES("8","Bangkok","2017-12-20","2017-12-29","1263","635","1898","28");
INSERT INTO `iteneraries` VALUES("9","Nairobi","2017-01-17","2019-01-17","546","631","1177","28");
INSERT INTO `iteneraries` VALUES("10","Beijing","2018-01-25","2019-02-25","100","1003","1103","28");
INSERT INTO `iteneraries` VALUES("11","Jakarta","2018-01-25","2018-02-28","100","5315","5415","28");
INSERT INTO `iteneraries` VALUES("12","London","2017-12-21","2017-12-27","54641","611","55252","38");
INSERT INTO `iteneraries` VALUES("13","Los Angeles","2018-01-25","2018-01-27","6554","645","7199","38");
INSERT INTO `iteneraries` VALUES("14","Pyongyang","2018-02-26","2019-03-28","10065","61316","71381","38");
INSERT INTO `iteneraries` VALUES("15","Smx Convention Center","2016-11-22","2016-11-22","3123","21312","24435","39");
INSERT INTO `iteneraries` VALUES("16","Tuguegarao City","2017-11-26","2017-11-27","100","100","200","40");
INSERT INTO `iteneraries` VALUES("17","Up Diliman, Qc","2018-02-24","2018-02-25","2000","2000","4000","42");
INSERT INTO `iteneraries` VALUES("18","Up Diliman, Qc","2018-02-24","2018-02-25","2000","2000","4000","42");
INSERT INTO `iteneraries` VALUES("19","Tuguegarao City","2018-11-29","2018-11-29","2000","2000","4000","43");
INSERT INTO `iteneraries` VALUES("20","Tuguegarao City","2018-01-25","2018-01-25","2000","2000","4000","43");
INSERT INTO `iteneraries` VALUES("21","Gonzaga","2018-01-19","2018-01-21","131321","1365","132686","45");



DROP TABLE IF EXISTS `reports`;

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `training_title` varchar(200) NOT NULL,
  `narrative` varchar(200) NOT NULL,
  `travel_order` varchar(200) NOT NULL,
  `training_request` varchar(200) NOT NULL,
  `cert_of_appearance` varchar(200) NOT NULL,
  `cert_participation` varchar(200) NOT NULL,
  `no_participants` varchar(6) NOT NULL,
  `date_submitted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `reports` VALUES("0","Mobile App","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","1","2018-01-10 13:40:19","42");
INSERT INTO `reports` VALUES("0","Mobile App","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","../images/NBC 461 PDS form.docx","1","2018-01-10 13:40:27","42");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","1","2018-01-10 20:26:45","28");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","1","2018-01-10 20:41:07","28");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","1","2018-01-10 20:42:52","28");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","1","2018-01-10 20:52:31","28");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","../images/cerebro-mecanico_23-2147506867.jpg","1","2018-01-10 20:56:07","28");
INSERT INTO `reports` VALUES("0","Toottip Test","../images/ACCOMPLISHMENT REPORT 2nd Sem Macugay Administration_temp.docx","../images/Appointment.pdf","../images/Sworn Statement of Assets, Liabilities and Net Worth.pdf","../images/Appointment.pdf","../images/Appointment.pdf","1","2018-01-11 10:45:37","28");



DROP TABLE IF EXISTS `seminars_attended`;

CREATE TABLE `seminars_attended` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_seminar_attended` varchar(50) NOT NULL,
  `date_attended` varchar(150) NOT NULL,
  `venue` varchar(150) NOT NULL,
  `expend` int(150) NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `seminars_attended` VALUES("1","Y4it","2017-12-23","SAN BEDA","100","2");
INSERT INTO `seminars_attended` VALUES("2","Y4it","2017-12-23","SAN BEDA","100","2");
INSERT INTO `seminars_attended` VALUES("3","Y4it","2017-12-23","SAFSDF","100","2");
INSERT INTO `seminars_attended` VALUES("4","Y4it","2017-12-23","SDGGSDGSD","100","2");
INSERT INTO `seminars_attended` VALUES("5","Y4it","2017-12-23","HMMM","100","2");
INSERT INTO `seminars_attended` VALUES("6","Y4it","2017-12-23","HMM","100","2");
INSERT INTO `seminars_attended` VALUES("7","Y4it","2017-12-23","HMM","100","2");
INSERT INTO `seminars_attended` VALUES("8","Y4it","2017-12-23","INJ","100","2");
INSERT INTO `seminars_attended` VALUES("9","Y4it","2017-12-23","UG","100","2");
INSERT INTO `seminars_attended` VALUES("10","Y4it","2017-12-23","GIU","100","2");
INSERT INTO `seminars_attended` VALUES("11","Y4it","2017-12-23","HMM","100","38");
INSERT INTO `seminars_attended` VALUES("12","Toottip Test","2017-12-24","TEST ULIT","100","28");
INSERT INTO `seminars_attended` VALUES("13","Toottip Test","2017-12-24","TEST","100","28");
INSERT INTO `seminars_attended` VALUES("14","Toottip Test","2017-12-24","TEST ULET","100","28");
INSERT INTO `seminars_attended` VALUES("15","Toottip Test","2017-12-24","BKDSFDFS","100","28");
INSERT INTO `seminars_attended` VALUES("16","Toottip Test","2017-12-24","3432","100","28");
INSERT INTO `seminars_attended` VALUES("17","Mobile App","2018-01-10","UP DILIMAN QC","4000","42");
INSERT INTO `seminars_attended` VALUES("18","Mobile App","2018-01-10","UP DILIMAN QC","4000","42");
INSERT INTO `seminars_attended` VALUES("19","Toottip Test","2018-01-10","100000","100","28");
INSERT INTO `seminars_attended` VALUES("20","Toottip Test","2018-01-10","10000","100","28");
INSERT INTO `seminars_attended` VALUES("21","Toottip Test","2018-01-10","1000","100","28");
INSERT INTO `seminars_attended` VALUES("22","Toottip Test","2018-01-10","10","100","28");
INSERT INTO `seminars_attended` VALUES("23","Toottip Test","2018-01-10","1362","100","28");
INSERT INTO `seminars_attended` VALUES("24","Toottip Test","2018-01-11","GONZAGA","100","28");



DROP TABLE IF EXISTS `trainings`;

CREATE TABLE `trainings` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `training_title` varchar(150) NOT NULL,
  `training_date` varchar(150) NOT NULL,
  `sponsor_institution` varchar(150) NOT NULL,
  `endorsement` varchar(150) NOT NULL,
  `training_officer` varchar(150) NOT NULL,
  `completion_date` varchar(150) NOT NULL,
  `venue` varchar(150) NOT NULL,
  `return_to_post` varchar(150) NOT NULL,
  `reason_of_participation` varchar(150) NOT NULL,
  `project_title` varchar(150) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date_of_submission` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `trainings` VALUES("1","Test","2018-11-24","CSUG","Richard Ayuyang","Richard Ayuyang","2018-11-24","Gonzaga","2018-11-24","Acquire basic skills for the position as newly hired employee","Programming","38","2017-12-23 19:15:58");
INSERT INTO `trainings` VALUES("2","Y4it","2018-11-24","CSUG","Richard Ayuyang","Richard Ayuyang","2019-10-25","Gonzaga","2018-10-25","Conduct echo/peer teaching for other member(s)","Programming","38","2017-12-23 19:16:38");
INSERT INTO `trainings` VALUES("3","Laravel","2019-11-25","CICS","Sample Endorsement","Richard Ayuyang","2018-11-25","Gonzaga","2019-10-25","Acquire new skills due to transfer to another section or promotion","Networking","38","2017-12-23 19:17:31");
INSERT INTO `trainings` VALUES("4","Bootstrap Css","2019-02-05","CICS","Cics","Richard Ayuyang","2019-12-25","Gonzaga","2019-10-25","Acquire basic skills for the position as newly hired employee","Html","38","2017-12-23 19:18:21");
INSERT INTO `trainings` VALUES("5","Networking","2018-01-24","agmalas","Elmarie Suetos","Richard Ayuyang","2018-01-24","Gonzaga","2018-01-24","Conduct echo/peer teaching for other member(s)","Html","28","2017-12-23 19:21:22");
INSERT INTO `trainings` VALUES("6","Laravel","2018-01-24","CICS","Elmarie Suetos","Richard Ayuyang","2018-01-24","Gonzaga","2017-01-24","Acquire basic skills for the position as newly hired employee","Html","28","2017-12-23 19:22:12");
INSERT INTO `trainings` VALUES("7","Toottip Test","2018-01-25","CICS","Cics","User","2018-11-25","Smx Pasay","2018-01-25","Acquire basic skills for the position as newly hired employee","Html","28","2017-12-24 12:13:35");
INSERT INTO `trainings` VALUES("8","Y4it","2018-01-25","CSUG","Cics","Earnest Filler","2018-01-25","Bangkok","2018-01-25","Acquire basic skills for the position as newly hired employee","Price Bait","28","2017-12-24 16:29:50");
INSERT INTO `trainings` VALUES("9","How To Write The Perfect Headline","2018-01-25","Deximo","Audie Harshaw","Crystal Ghastly","2018-01-25","Nairobi","2018-01-25","Conduct echo/peer teaching for other member(s)","Skatech","28","2017-12-24 16:33:58");
INSERT INTO `trainings` VALUES("10","10 Best Practices For Seminar","2018-01-25","Yellow Leather","Forgotten Bulldozer","Xylophone Gruesome","2018-01-25","Beijing","2018-01-25","Acquire basic skills for the position as newly hired employee","10 Best Practices For Seminar","28","2017-12-24 16:36:48");
INSERT INTO `trainings` VALUES("11","Raw Poseidon","2018-01-25","Tuba Stormy","Solid Cobra","Teresita Gunnerson","2018-01-26","Jakarta","2018-01-25","Conduct echo/peer teaching for other member(s)","Raw Poseidon","28","2017-12-24 16:38:32");
INSERT INTO `trainings` VALUES("12","7 Easy Ways To Make Seminar Faster","2018-01-25","Plexcorporation","Plexcorporation","Avelina Vahle","2017-12-13","London","2018-01-25","Acquire new skills due to transfer to another section or promotion","7 Easy Ways To Make Seminar Faster","38","2017-12-24 16:41:02");
INSERT INTO `trainings` VALUES("13","Marriage And Semianar Have More In Common Than You Think","2019-01-25","bluedax","Bluedax","Enedina Sproul","2018-01-25","Los Angeles","2018-01-25","Conduct echo/peer teaching for other member(s)","Marriage And Semianar Have More In Common Than You Think","38","2017-12-24 16:42:23");
INSERT INTO `trainings` VALUES("14","Why Some People Almost Always Make/save Money With Semianar","2018-01-26","Bitter Street","Bitter Street","Latashia Rodney","2018-01-26","Pyongyang","2018-01-26","Acquire new skills due to transfer to another section or promotion","Why Some People Almost Always Make/save Money With Semianar","38","2018-01-11 10:41:49");
INSERT INTO `trainings` VALUES("15","Programming","2016-11-24","CICS","Sample","Mark Oliver Sosa","2016-11-24","Smx Convention Center","2016-11-24","Acquire basic skills for the position as newly hired employee","Laravel","39","2017-12-25 13:09:07");
INSERT INTO `trainings` VALUES("16","Y4it","2017-11-27","College of Hospitality Industry Management","Bill Gates","Mark Zuckerberg","2017-11-30","Tuguegarao City","2017-11-30","Conduct echo/peer teaching for other member(s)","Y4it","40","2017-12-26 19:14:06");
INSERT INTO `trainings` VALUES("17","Mobile App","2018-02-23","UP Diliman","Mr. Richard Ayuyang","Avelina Ayuyang","2018-02-27","Up Diliman, Qc","2018-02-28","Improve performance in current job or function","Mobile App Seminar","42","2018-01-10 13:30:31");
INSERT INTO `trainings` VALUES("18","Mobile App","2018-02-25","UP Diliman","Mr. Richard Ayuyang","Avelina Ayuyang","2018-02-28","Up Diliman Qc","2018-02-28","Improve performance in current job or function","Mobile App Seminar","42","2018-01-10 13:37:56");
INSERT INTO `trainings` VALUES("19","Multimedia Seminar","2018-11-29","UCV","Richard Ayuyang","Avelina Ayuyang","2018-12-06","Tuguegarao City","2018-12-06","Acquire new skills due to transfer to another section or promotion","Multimedia Seminar","43","2018-01-10 16:01:23");
INSERT INTO `trainings` VALUES("20","Multimedia Seminar","2018-01-25","UCV","Richard Ayuyang","Avelina Ayuyang","2018-01-30","Tuguegarao City","2018-01-25","Acquire basic skills for the position as newly hired employee","Multimedia","43","2018-01-10 16:04:09");
INSERT INTO `trainings` VALUES("21","Embeded System","2018-01-18","Cgayan State university","Training Endorsement","Training Officer Name","2018-01-19","Gonzaga","2018-01-19","Improve performance in current job or function","Training Officer Name`","45","2018-01-11 10:42:31");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES("1","admin","3a581956b09017a876fb2cfac952449efc3956c5","admin");
INSERT INTO `users` VALUES("2","budget_officer","4fd06a037e77e752d530729628de8f0f1bdf8b83","accounting");
INSERT INTO `users` VALUES("3","fsd_coordinator","3ffc7ecfcb1656f37af87808a25031265a6872be","coordinator");
INSERT INTO `users` VALUES("28","11-0001","3a581956b09017a876fb2cfac952449efc3956c5","employee");
INSERT INTO `users` VALUES("29","14-1001","280471a870525538b2c3d127435135001b0f8bf4","employee");
INSERT INTO `users` VALUES("30","15-0001","4fd06a037e77e752d530729628de8f0f1bdf8b83","employee");
INSERT INTO `users` VALUES("31","15-0002","2f91f73e4cf97210477e22cff93366ffdc5a67bf","employee");
INSERT INTO `users` VALUES("32","15-0003","2f91f73e4cf97210477e22cff93366ffdc5a67bf","employee");
INSERT INTO `users` VALUES("33","15-0004","2f91f73e4cf97210477e22cff93366ffdc5a67bf","employee");
INSERT INTO `users` VALUES("34","15-0005","2f91f73e4cf97210477e22cff93366ffdc5a67bf","employee");
INSERT INTO `users` VALUES("35","15-0006","2f91f73e4cf97210477e22cff93366ffdc5a67bf","employee");
INSERT INTO `users` VALUES("36","23-00001","280471a870525538b2c3d127435135001b0f8bf4","employee");
INSERT INTO `users` VALUES("37","R-933","4672be011ccf1d1ae1b0db02b058fb782a944158","employee");
INSERT INTO `users` VALUES("38","11-0004","0a71f8ee8789a57a3d32573e229e4518082df018","employee");
INSERT INTO `users` VALUES("39","15-00006","1f76c9d21a54cf493096e7b6d130f3f094176355","employee");
INSERT INTO `users` VALUES("40","11-1111","280471a870525538b2c3d127435135001b0f8bf4","employee");
INSERT INTO `users` VALUES("41","11-2345","280471a870525538b2c3d127435135001b0f8bf4","employee");
INSERT INTO `users` VALUES("42","113","92b013eac228eb5358f1f8416516c41524961729","employee");
INSERT INTO `users` VALUES("43","092","4044e5f1e1d686f21795b251bdf87c70ae467b63","employee");
INSERT INTO `users` VALUES("44","123-321","280471a870525538b2c3d127435135001b0f8bf4","pending");
INSERT INTO `users` VALUES("45","11-111","24cf133f8ac4a82a7244dc9d9c770b6bbebade68","employee");



