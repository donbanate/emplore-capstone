<?php 
	session_start();
	include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

    if (!isset($_SESSION['id']) OR $checkUser['type'] != 'employee') {
		echo "<script>window.open('../index.php','_self');</script>";
	}else{
		include '../db_connection/db_conn.php';

		$id = addslashes($_GET['id']);
		$del  = "DELETE FROM approvals WHERE id = '$id';";
		$del .= "DELETE FROM trainings WHERE id = '$id';";
		$del .= "DELETE FROM employee_training_needs WHERE id = '$id';";
		$del .= "DELETE FROM iteneraries WHERE id = '$id';";

		if ($conn->multi_query($del) === TRUE) {
			echo "<script>alert('Training deleted successfully!');</script>";
			echo "<script>window.open('sentTrainings.php', '_self');</script>";
		}
	}
?>
