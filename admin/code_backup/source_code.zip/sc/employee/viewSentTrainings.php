<?php 
	session_start();
	include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

    if (!isset($_SESSION['id']) OR $checkUser['type'] != 'employee') {
		echo "<script>window.open('../index.php', '_self');</script>";
	}else{
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training Full Details</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">

    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link href="../libs/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/styles.css" />
</head>
<body>
	<div class="col-8 offset-2">
		<div class="table-responsive">
			<h3 class="alert alert-info"><b>Training Details</b></h3>
			<?php  
				$id = $_GET['id'];
				$sql  = "SELECT * FROM trainings WHERE id = '$id'";
				$result = $conn->query($sql);
    			$row = $result->fetch_assoc();
			?>
			<table class="table table-striped">
				<tr>
					<th>Training Title</th>
					<td><?=$row['training_title']?></td>
				</tr>
				<tr>
					<th>Training Date</th>
					<td><?=$row['training_date']?></td>
				</tr>
				<tr>
					<th>Sponsor Institution</th>
					<td><?=$row['sponsor_institution']?></td>
				</tr>
				<tr>
					<th>Endorsement</th>
					<td><?=$row['endorsement']?></td>
				</tr>
				<tr>
					<th>Training Officer</th>
					<td><?=$row['training_officer']?></td>
				</tr>
				<tr>
					<th>Completion Date</th>
					<td><?=$row['completion_date']?></td>
				</tr>
				<tr>
					<th>Venue</th>
					<td><?=$row['venue']?></td>
				</tr>
				<tr>
					<th>Return-to-post</th>
					<td><?=$row['return_to_post']?></td>
				</tr>
				<tr>
					<th>Reason of Participation</th>
					<td><?=$row['reason_of_participation']?></td>
				</tr>
				<tr>
					<th>Project Title</th>
					<td><?=$row['project_title']?></td>
				</tr>
			</table>
			<a class="btn" href="sentTrainings.php"><span class="fa fa-chevron-left"></span> BACK</a>
		</div>
	</div>
</body>
</html>
<?php  
}
?>