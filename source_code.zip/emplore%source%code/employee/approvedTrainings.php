<?php
	session_start();
	include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

	if (isset($_SESSION['id']) OR $checkUser['type'] == 'employee') {
		include '../db_connection/db_conn.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Trainings Attended</title>
	<link rel="icon" type="image/png" href="../logo/logo.png">
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link href="../libs/font-awesome.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="../css/styles.css" />
</head>
<body>
<div class="col-lg-12">
	<div id="printBtn">
		<a href="index.php" class="btn btn-outline-info"><i class="fa fa-chevron-left"></i> BACK</a>
		<button onclick="printWindow()"  class="btn btn-outline-success"><i class="fa fa-print"></i> Print</button>
	</div>
</div>
<p></p>
	<div class="col-12">
		<div class="table-responsive">
			<?php  
				$id = addslashes($_SESSION['id']);
				$sql = "SELECT * FROM users AS U, employees AS E, trainings AS T, employee_training_needs AS N, iteneraries AS I, approvals AS A WHERE U.id = E.id AND E.id = T.employee_id AND T.id = N.id AND T.id = I.id AND T.id = A.id AND A.remark_type = 'Approved' AND E.id = '$id'";
				$result = $conn->query($sql);
				
			?>
			<table class="table table-bordered">
				<thead class="thead-light">
					<tr>
						<th>Training Title</th>
						<th>Training Date</th>
						<th>Venue</th>
						<th>Endorsement</th>
						<th>Sponsor Institution</th>
						<th>Project Title</th>
						<th>Reason of Participation</th>
						<th>Total Training Expenses Incurred</th>
						<th>Itenerary Total Expense</th>
						<th>Completion Date</th>
					</tr>
				</thead>
			<?php 
				while ($getTrainings = $result->fetch_assoc()) { 
				?>
				<tbody>
					<tr>
						<td><?=$getTrainings['training_title']?></td>
						<td><?=$getTrainings['training_date']?></td>
						<td><?=$getTrainings['venue']?></td>
						<td><?=$getTrainings['endorsement']?></td>
						<td><?=$getTrainings['sponsor_institution']?></td>
						<td><?=$getTrainings['project_title']?></td>
						<td><?=$getTrainings['reason_of_participation']?></td>
						<td><?=$getTrainings['total_expenses_to_be_incurred']?></td>
						<td><?=$getTrainings['expenses']?></td>
						<td><?=$getTrainings['completion_date']?></td>
					</tr>
				</tbody>
				<?php } ?>
			</table>
			<br>
			<br>
			<br>
			<?php
			$user = $_SESSION['id'];
			$sql1 = "SELECT * FROM users AS U, employees AS E, employee_designations AS D WHERE U.id = E.id AND U.id = D.id AND U.id = '$user' ";
			$result1 = $conn->query($sql1); 
			$row = $result1->fetch_assoc(); 
			?>
			<h5><?=$row['first_name'] . ' ' .$row['middle_name'] . ' '.$row['last_name'] . ' '.$row['name_extension']?></h5>
			<p><?=$row['designated_as']?></p>
		</div>
	</div>
</body>
</html>
<!--scripts loaded here--> 
    
    <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    
    <script src="../js/scripts.js"></script>
    <script type="text/javascript">
	function printWindow(){
		document.getElementById("printBtn").hidden = true;
		window.print();
		document.getElementById("printBtn").hidden = false;
	}
</script>
    <script>
        $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
<?php
		
	}else{ 
		echo "<script>window.open('../index.php', '_self');</script>";	
	}
?>