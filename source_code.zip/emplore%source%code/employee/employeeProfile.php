<?php
	session_start();  
	include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

    if (!isset($_SESSION['id']) OR $checkUser['type'] != 'employee') {
		echo "<script>window.open('../index.php', '_self')</script>";
	}else{
		include '../db_connection/db_conn.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Your Profile</title>
	<link rel="icon" type="image/png" href="../logo/logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">

    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link href="../libs/font-awesome.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="../css/styles.css" />
</head>
<body>

		<?php  
			$id = addslashes($_SESSION['id']); 
			$sql = "SELECT * FROM users AS U, employees AS E, employee_designations AS D WHERE U.id = E.id AND U.id = D.id AND U.id ='$id' ";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
		?>
		
		<div class="card-body col-8 offset-2">
			<div class="card-header"><img style="height: 20%; width: 20%;" src="../logo/profile.png"><strong><p style="margin-bottom: 0%"><?=$row['username']?></p><p><?=$row['first_name'] . ' '.$row['middle_name'] . ' '.$row['last_name'] .' '.$row['name_extension']?>, <i><?=$row['designated_as']?></i></p></strong>

				<button class="btn btn-outline-info" data-target="#myModal" data-toggle="modal"><i class="fa fa-edit"></i> Edit Details</button></div>
			<div class="table-responsive">
		
			<table class="table table-striped">
				<tr>
					<th>Age</th>
					<th><?=$row['age']?></th>
				</tr>
				<tr>
					<th>Sex</th>
					<td><?=$row['sex']?></td>
				</tr>
				<tr>
					<th>Birthdate</th>
					<td><?=$row['birth_date']?></td>
				</tr>
				<tr>
					<th>Birthplace</th>
					<td><?=$row['birth_place']?></td>
				</tr>
				<tr>
					<th>Address</th>
					<td><?=$row['barangay'] . ', '. $row['address']?></td>
				</tr>
				<tr>
					<th>Mobile Number</th>
					<td><?=$row['mobile_no']?></td>
				</tr>
			</table>
			<a data-toggle="tooltip" title="GO HOME" data-placement ="left" class="btn btn-default"  href="index.php"><i class="fa fa-chevron-left"></i></a>
		</div>
		</div>

</body> 
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Edit your personal details</h4>
            </div>
            <div class="modal-body"> 
            <?php  

                if (isset($_POST['update_info'])) {
                $id = addslashes($_GET['id']);
                $fname = addslashes(ucfirst(strtolower($_POST['fname'])));
                $midname = addslashes($_POST['midname']);
                $lname = addslashes(ucwords(strtolower($_POST['lname'])));
                $namex = addslashes(ucwords(strtolower($_POST['namex'])));
                $age = addslashes(trim($_POST['age']));

                #end
                $barangay = addslashes(ucwords(strtolower($_POST['barangay'])));
                $muni =    addslashes(ucwords(strtolower($_POST['muni'])));
                $mobile = addslashes($_POST['number']);
                $desig = addslashes($_POST['desig']);

                $update = "UPDATE users AS U, employees AS E ,employee_designations AS D SET E.first_name = '$fname', E.middle_name = '$midname', E.last_name = '$lname', E.name_extension = '$namex', E.age = '$age',E.barangay = '$barangay', E.address = '$muni', E.mobile_no = '$mobile', D.designated_as = '$desig' WHERE U.id = E.id AND E.id = '$id' ";

                if ($conn->query($update) === TRUE) {
        ?>
                <div class="alert alert-success" role="alert">
                    <script type="text/javascript">
                    	alert('Great! Your profile has been updated.');
                        window.open('employeeProfile.php', '_self');
                    </script>
                </div>
        <?php

                }

            }
        ?>
                <form method="POST" action="employeeProfile.php?id=<?=$row['id']?>">
                	  
                	<div class="row">
                		<div class="form-group col-6">
                			<label>Firstname</label>
                			<input class="form-control" type="text" name="fname" value="<?=$row['first_name']?>" required>
                		</div>
                		<div class="form-group col-6">
                			<label>Middlename</label>
                			<input class="form-control" type="text" name="midname" required="" value="<?=$row['middle_name']?>">
                		</div>
                	</div>
                	<div class="row">
                		<div class="form-group col-12">
                			<label>Lastname</label>
                			<input class="form-control" type="text" name="lname" required="" value="<?=$row['last_name']?>">
                		</div>
                	</div>
                	<div class="row">
                		<div class="form-group col-6">
                			<label>Name extension</label>
                			<input class="form-control" type="text" name="namex" value="<?=$row['name_extension']?>">
                		</div>
                		<div class="form-group col-6">
                			<label>Age</label>
                			<input class="form-control" type="number" name="age" value="<?=$row['age']?>">
                		</div>
                	</div>
                	<div class="row">
         				<div class="form-group col-6">
         					<label>Barangay</label>
         					<input class="form-control" type="text" name="barangay" value="<?=$row['barangay']?>">
         				</div>
         				<div class="form-group col-6">
         					<label>Municipality</label>
         					<input class="form-control" type="text" name="muni" value="<?=$row['address']?>">
         				</div>
                	</div>
                	<div class="row">
						<div class="form-group col-6">
							<label>Mobile Number</label>
							<input class="form-control" type="number" name="number" value="<?=$row['mobile_no']?>">
						</div> 
						<div class="form-group col-6">
							<label>Designation</label>
							<input class="form-control" type="text" name="desig" value="<?=$row['designated_as']?>">
						</div>               		
                	</div>
                	<button type="submit" class="btn btn-outline-warning" name="update_info"><i class="fa fa-gears"></i> <strong>Update</strong></button>
                </form>

            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-primary-outline" data-dismiss="modal">OK</button> -->
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            </div>
        </div> 
    </div>
</div>
<!-- -->

<script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    
    <script src="../js/scripts.js"></script>
    <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>
<?php
}
?>