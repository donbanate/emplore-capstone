<?php
	session_start(); 
	include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

    if (!isset($_SESSION['id']) OR $checkUser['type'] != 'employee') {
		echo "<script>window.open('../index.php', '_self');</script>";
	}else{

		if (isset($_POST['request'])) {
			$gi_training      = ucwords(strtolower(trim($_POST['gi_training'])));
		      $gi_training_date = ucwords(strtolower(trim($_POST['gi_training_date'])));
		      $gi_sponsor       = trim($_POST['gi_sponsor']);
		      $gi_endorsement   = ucwords(strtolower(trim($_POST['gi_endorsement'])));
		      $gi_trainingop    = ucwords(strtolower(trim($_POST['gi_trainingop'])));
		      $gi_completion    = trim($_POST['gi_completion']);
		      $gi_venue         = ucwords(strtolower(trim($_POST['gi_venue'])));
		      $gi_return        = trim($_POST['gi_return']);
		      $gi_project       = ucwords(strtolower(trim($_POST['gi_project'])));
		      $gi_reason        = ucfirst($_POST['gi_reason']);
		      $gi_reason1       = ucfirst($_POST['gi_reason1']);

		      if (isset($gi_reason1) AND $gi_reason1 != '' AND $gi_reason1 != ' ') {  
		        $reasonFinal = $gi_reason . ' and ' . $gi_reason1;
		      }else{
		        $reasonFinal = $gi_reason;
		      }
		      #end ---------------------------------------------------------------------

		      //Projected Incidental Expenses
		      $proj_transpo     = trim($_POST['proj_transpo']);
		      $proj_tcpd        = trim($_POST['proj_tcpd']);
		      $proj_stf         = trim($_POST['proj_stf']);
		      $proj_exp         = addslashes($proj_transpo + $proj_tcpd + $proj_stf);
		      #end----------------------------------------------------------------------

		      //Itenary
		      $it_venue         = ucwords(strtolower($_POST['it_venue']));
		      $it_exp           = trim($_POST['it_exp']);
		      $it_transpo       = trim($_POST['it_transpo']);
		      $it_doa           = trim($_POST['it_doa']);
		      $it_ddepart       = trim($_POST['it_ddepart']);
		      $it_total_exp     = addslashes($it_transpo + $it_exp);    
		      #end----------------------------------------------------------------------

		

		      $_SESSION['gi_training'] 		= $gi_training;
		      $_SESSION['gi_endorsement'] 	= $gi_endorsement;
		      $_SESSION['gi_trainingop']	= $gi_trainingop;
		      $_SESSION['gi_reason']		= $gi_reason;
		      $_SESSION['gi_sponsor'] 		= $gi_sponsor;
		      $_SESSION['gi_return'] 		= $gi_return;
		      $_SESSION['gi_venue']			= $gi_venue;
		      $_SESSION['gi_completion']	= $gi_completion;
		      $_SESSION['gi_training_date']	= $gi_training_date;
		      $_SESSION['gi_reason1']		= $gi_reason1;
		      $_SESSION['gi_reason']		= $gi_reason;
		      $_SESSION['gi_project']		= $gi_project;
		      $_SESSION['reasonFinal'] 		= $reasonFinal;		      

		      $_SESSION['proj_tcpd']		= $proj_tcpd;
		      $_SESSION['proj_stf']			= $proj_stf;
		      $_SESSION['proj_transpo']		= $proj_transpo;
		      $_SESSION['proj_exp']			= $proj_exp;

		      $_SESSION['it_transpo']		= $it_transpo;
		      $_SESSION['it_ddepart']		= $it_ddepart;
		      $_SESSION['it_doa']			= $it_doa;
		      $_SESSION['it_venue']			= $it_venue;
		      $_SESSION['it_total_exp']		= $it_total_exp;
		      $_SESSION['it_exp']			= $it_exp;
		}

		if (isset($_POST['confirm'])) {	
			  //Employee id
      		  $eid = $_SESSION['id'];

    		  //General Information
     		  $gi_training = $_SESSION['gi_training'];
		      $gi_endorsement = $_SESSION['gi_endorsement'];
		      $gi_trainingop = $_SESSION['gi_trainingop'];
		      $gi_reason = $_SESSION['gi_reason'];
		      $gi_sponsor = $_SESSION['gi_sponsor'];
		      $gi_return = $_SESSION['gi_return'];
		      $gi_venue = $_SESSION['gi_venue'];
		      $gi_completion = $_SESSION['gi_completion'];
		      $gi_training_date = $_SESSION['gi_training_date'];
		      $gi_reason1 = $_SESSION['gi_reason1'];
		      $gi_reason = $_SESSION['gi_reason'];
		      $reasonFinal = $_SESSION['reasonFinal'];
		      $gi_project = $_SESSION['gi_project'];

		      $proj_tcpd = $_SESSION['proj_tcpd'];
		      $proj_stf = $_SESSION['proj_stf'];
		      $proj_transpo = $_SESSION['proj_transpo'];
		      $proj_exp = $_SESSION['proj_exp'];

		      $it_transpo = $_SESSION['it_transpo'];
		      $it_ddepart = $_SESSION['it_ddepart'];
		      $it_doa = $_SESSION['it_doa'];
		      $it_venue = $_SESSION['it_venue'];
		      $it_total_exp = $_SESSION['it_total_exp'];
		      $it_exp = $_SESSION['it_exp'];

		      if (!ctype_digit($proj_tcpd) || !ctype_digit($proj_stf)) {
		      echo "<script>alert('Incorrect');</script>";
		      echo "<script>window.open('SendTrainingRequest.php', '_self');</script>";
		      }elseif(strtotime($it_ddepart) > strtotime($it_doa)){
		      echo "<script>alert('Departure time must not be later than the arrival time. Thank you!');</script>";
		      echo "<script>window.open('SendTrainingRequest.php', '_self');</script>";
		      }else{

			      $sql = "INSERT INTO trainings(training_title, training_date, sponsor_institution, endorsement, training_officer, completion_date, venue, return_to_post, reason_of_participation, project_title, employee_id) VALUES ('$gi_training', '$gi_training_date', '$gi_sponsor', '$gi_endorsement', '$gi_trainingop', '$gi_completion', '$gi_venue', '$gi_return', '$reasonFinal', '$gi_project', '$eid');";

			      $sql .= "INSERT INTO employee_training_needs(transportation_expense, total_cost_of_per_diem, seminar_training_fee, total_expenses_to_be_incurred, training_title, remark, reasons, employee_id) VALUES ('$proj_transpo', '$proj_tcpd', '$proj_stf', '$proj_exp', '$gi_training', 'unchecked', ' ','$eid');";

			      $sql .= "INSERT INTO iteneraries(venue, date_departure, date_arrival, transportation, expenses, total, employee_id) VALUES ('$it_venue', '$it_ddepart', '$it_doa', '$it_transpo', '$it_exp', '$it_total_exp', '$eid');";

			      $sql .= "INSERT INTO approvals(remark_type, employee_id) VALUES ('unchecked', '$eid');";

				  unset($_SESSION['gi_training']);
				  unset($_SESSION['gi_endorsement']);
				  unset($_SESSION['gi_trainingop']);
				  unset($_SESSION['gi_reason']);
				  unset($_SESSION['gi_sponsor']);
				  unset($_SESSION['gi_return']);
				  unset($_SESSION['gi_venue']);
				  unset($_SESSION['gi_completion']);
				  unset($_SESSION['gi_training_date']);
				  unset($_SESSION['gi_lsa']);
				  unset($_SESSION['gi_reason1']);
				  unset($_SESSION['gi_reason']);
				  unset($_SESSION['gi_project']);
				  unset($_SESSION['reasonFinal']);		      

				  unset($_SESSION['proj_tcpd']);
				  unset($_SESSION['proj_stf']);
				  unset($_SESSION['proj_transpo']);
				  unset($_SESSION['proj_exp']);

				  unset($_SESSION['it_transpo']);
				  unset($_SESSION['it_ddepart']);
				  unset($_SESSION['it_doa']);
				  unset($_SESSION['it_venue']);
				  unset($_SESSION['it_total_exp']);
				  unset($_SESSION['it_exp']);


				  if ($conn->multi_query($sql) === TRUE) {
		            echo '<script>alert("Request successfully sent!");</script>';
		            echo '<script>window.open("SendTrainingRequest.php", "_self");</script>';
		           }else{
		                    echo "Error: " . $sql . "<br>" . $conn->error;
		        	}
		    	}
		    }else{	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Validate Request</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link href="../libs/font-awesome.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="../css/styles.css" />
</head>
<body>
<div class="col-8 offset-2">
            <div class="col-lg-12 col-md-8">
            <h4 class="alert alert-warning"><i>*Take a second look</i></h4>
            <p></p>
            <div class="table-responsive">
            <form method="POST" action="finalRequest.php">
            	<table class="table table-striped">
            <thead class="thead-inverse">
            <tr>
				<th colspan="2"><h4 class="alert alert-info">General Information</h4></th>
			</tr>
			<tr>
				<th>Training Title</th>
				<td><?php echo $_SESSION['gi_training']; ?></td>
			</tr>
			<tr>
				<th>Training Date</th>
				<td><?php echo $_SESSION['gi_training_date']; ?></td>
			</tr>
			<tr>
				<th>Endorsement</th>
				<td><?php echo $_SESSION['gi_endorsement']; ?></td>
			</tr>
			<tr>
				<th>Sponsoring Institution</th>
				<td><?php echo $_SESSION['gi_sponsor']; ?></td>
			</tr>
			<tr>
				<th>Training Officer</th>
				<td><?php echo $_SESSION['gi_trainingop']; ?></td>
			</tr>
			<tr>
				<th>Venue</th>
				<td><?php echo $_SESSION['gi_venue']; ?></td>
			</tr>
			<tr>
				<th>Return-to-post</th>
				<td><?php echo $_SESSION['gi_return']; ?></td>
			</tr>
			<tr>
				<th>Reason(s) of participation</th>
				<td><?php echo $_SESSION['gi_reason']; ?></td>
			</tr>
			<tr>
				<th>Project Title</th>
				<td><?php echo $_SESSION['gi_project']; ?></td>
			</tr>
			<tr>
				<th>Completion Date</th>
				<td><?php echo $_SESSION['gi_completion']; ?></td>
			</tr>
			<tr>
				<th colspan="2"><h4 class="alert alert-info">Projected Incidental Expenses</h4></th>
			</tr>
			<tr>
				<th>Transportation Expense</th>
				<td><?php echo $_SESSION['proj_transpo']; ?></td>
			</tr>
			<tr>
				<th>Total Cost of Per Diem</th>
				<td><?php echo $_SESSION['proj_tcpd']; ?></td>
			</tr>
			<tr>
				<th>Seminar Training Fee</th>
				<td><?php echo $_SESSION['proj_transpo']; ?></td>
			</tr>
			<tr>
				<th>Venue</th>
				<td><?php echo $_SESSION['it_venue']; ?></td>
			</tr>
			<tr>
				<th>Date of Departure</th>
				<td><?php echo $_SESSION['it_ddepart']; ?></td>
			</tr>
			<tr>
				<th>Date of Arrival</th>
				<td><?php echo $_SESSION['it_doa']; ?></td>
			</tr>
			<tr>
				<th>Transportation</th>
				<td><?php echo $_SESSION['it_transpo']; ?></td>
			</tr>
			<tr>
				<th>Expenses</th>
				<td><?php echo $_SESSION['it_exp']; ?></td>
			</tr>
           </thead>
           <tr>
           		<th colspan="2">
           			<a class="btn btn-lg" data-toggle="tooltip" title="GO BACK" href="SendTrainingRequest.php"><i class="fa fa-chevron-left"></i> BACK</a>&nbsp;&nbsp;&nbsp;&nbsp;	
      <button class="btn btn-success btn-lg" name="confirm" type="submit">Send <span class="fa fa-send"></span></button></th>
           </tr>
           <!--scripts loaded here-->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    
    <script src="../js/scripts.js"></script>
	<script>
		$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip();
		});
	</script>
        </table>
            </form>
                    </div>
                </div>
            </div>
</body>
</html>
<?php
	}
}
?>