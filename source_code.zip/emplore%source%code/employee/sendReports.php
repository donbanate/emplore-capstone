<?php  
    session_start();
    include '../db_connection/db_conn.php';
    $user = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$user' ";
    $result = $conn->query($sql);
    $checkUser = $result->fetch_assoc();

    if (!isset($_SESSION['id']) OR $checkUser['type'] != 'employee') {
            echo "<script>window.open('../index.php', '_self');</script>";
    }else{      
    $user = $_GET['id'];

    if (isset($_POST['send'])) {
        $id = addslashes($_POST['id']);
        $training_title = addslashes($_POST['training_title']);
        $img_file  = $_FILES['narrative_report']['tmp_name'];
        $img_name  = $_FILES['narrative_report']['name'];

        $img_file1 = $_FILES['travel_order']['tmp_name'];
        $img_name1 = $_FILES['travel_order']['name'];

        $img_file2 = $_FILES['training_request']['tmp_name'];
        $img_name2 = $_FILES['training_request']['name'];

        $img_file3 = $_FILES['coa']['tmp_name'];
        $img_name3 = $_FILES['coa']['name'];

        $img_file4 = $_FILES['cop']['tmp_name'];
        $img_name4 = $_FILES['cop']['name'];
        $img_path = '../images/';

        $path = $img_name;
        $imgExt = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $patha = $path.$imgExt;
        $image = $img_file;
        $db_path = $img_path . $path;

        $path1 = $img_name1;
        $imgExt1 = strtolower(pathinfo($path1, PATHINFO_EXTENSION));
        $path1a = $path1.$imgExt1;
        $image1 = $img_file1;
        $db_path1 = $img_path . $path1;

        $path2 = $img_name2;
        $imgExt2 = strtolower(pathinfo($path2, PATHINFO_EXTENSION));
        $path2a = $path2.$imgExt2;
        $image2 = $img_file2;
        $db_path2 = $img_path . $path2;

        $path3 = $img_name3;
        $imgExt3 = strtolower(pathinfo($path3, PATHINFO_EXTENSION));
        $path3a = $path3.$imgExt3;
        $image3 = $img_file3;
        $db_path3 = $img_path . $path3;

        $path4 = $img_name4;
        $imgExt4 = strtolower(pathinfo($path4, PATHINFO_EXTENSION));
        $path4a = $path4.$imgExt4;
        $image4 = $img_file4;
        $db_path4 = $img_path . $path4;

        $validExt = array("gif", "jpg", "jpeg", "png", "pdf", "docx", "ppt");
        $valid1 = 0;
        $valid2 = 0;
        $valid3 = 0;
        $valid4 = 0;
        $valid5 = 0;

        for ($i=0; $i < sizeof($validExt); $i++) { 
            if ($imgExt == $validExt[$i]) {
                $valid1 += 1;
            }
            if ($imgExt1 == $validExt[$i]) {
                $valid2 += 1;
            }
            if ($imgExt2 == $validExt[$i]) {
                $valid3 += 1;
            }
            if ($imgExt3 == $validExt[$i]) {
                $valid4 += 1;
            }
            if ($imgExt4 == $validExt[$i]) {
                $valid5 += 1;
            }
        }

        if ($valid1 > 0 AND $valid2 > 0 AND $valid3 > 0 AND $valid4 > 0 AND $valid5 > 0) {
            
            move_uploaded_file($image, $img_path.$path);
            move_uploaded_file($image1, $img_path.$path1);
            move_uploaded_file($image2, $img_path.$path2);
            move_uploaded_file($image3, $img_path.$path3);
            move_uploaded_file($image4, $img_path.$path4);

            $eid = $_SESSION['id'];
            $participants = $_POST['person_attended']; 

            $query = $conn->query("INSERT INTO reports(training_title, narrative,travel_order, training_request, cert_of_appearance, cert_participation, no_participants,employee_id) VALUES('$training_title', '$db_path','$db_path1', '$db_path2', '$db_path3', '$db_path4', '$participants','$eid')");
            $query1 = $conn->query("INSERT INTO approvals(comment) VALUES ('reported') WHERE employee_id = '$eid' ");

            date_default_timezone_set('Asia/Manila');
            $dateToday = date('Y-m-d');

            $venue = addslashes(strtoupper(trim($_POST['venue'])));
            $expenses = $_POST['expenses'];


            $query2 = $conn->query("INSERT seminars_attended(last_seminar_attended, date_attended, venue, expend, employee_id) VALUES('$training_title', '$dateToday', '$venue', '$expenses', '$eid')");

            if ($query === TRUE AND $query1 ===  TRUE AND $query2 ===  TRUE) {
?>
            <script type="text/javascript">
                alert('Report sent successfully!');
                window.open('approvals.php', '_self');
            </script>
<?php
               
            }
        }else{
            echo "<script>alert('Invalid file upload!');</script>";
            echo "<script>window.open('sendReports.php?id=". $id ."', '_self');</script>";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Send Reports</title>
    <link rel="icon" type="image/png" href="../logo/logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">

    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link href="../libs/font-awesome.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="../css/styles.css"/>

</head>
<body>
    <div class="card-block col-8 offset-2">
        <div class="card-header text-white bg-info"><h4><strong>Send Report <i class="fa fa-folder-open"></i></strong></h4></div>
        <div class="card-body">
        <form method="POST" action="sendReports.php?id=<?=$_GET['id']?>" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo addslashes($_GET['id']); ?>">
        <div class="form-group">
            <?php
                $id = addslashes($_GET['id']);
                $sql = "SELECT * FROM trainings WHERE id = '$id' ";
                $result =$conn->query($sql);
                $row = $result->fetch_assoc();
            ?>
            <label for="training_title"><strong>Training Title</strong></label>
            <input class="form-control" type="text" readonly="" value="<?=$row['training_title']?>" id="training_title" name="training_title" placeholder="Your training title here!">
        </div>
        <div class="row">
            <div class="form-group col-4">
                <label><strong>Venue</strong></label>
                <input class="form-control" type="text" name="venue" placeholder="Enter the training venue" required>
            </div>       
            <div class="form-group col-4">
                <label><strong>Expenses</strong></label>
                <input class="form-control" type="number" name="expenses" required min="100" value="100" >
            </div>
            <div class="form-group col-4">
                <label><strong>Number of Participants</strong></label>
                <input class="form-control" type="number" name="person_attended" required value="1" >
            </div>   
        </div>
        <h5><i>*Please use this file formats when uploading files(.docx, .jpg, .png, .pdf)</i></h5>
        <div class="form-group">
            <label for="narrative_report"><strong>Narrative Report</strong></label>
            <input class="form-control btn-success" type="file" name="narrative_report" id="narrative_report" required>
        </div>

        <div class="row">
            <div class="form-group col-6">
                <label for="travel_order"><strong>Travel Order</strong></label>
                <input class="form-control btn-success" type="file" name="travel_order" id="travel_order" required>
            </div>
            <div class="form-group col-6">
                <label for="training_request"><strong>Training Request</strong></label>
                <input class="form-control btn-success" type="file" name="training_request" id="training_request" required>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-6">
                <label for="coa"><strong>Certificate of Appearance</strong></label>
                <input class="form-control btn-success" type="file" name="coa" id="coa" required>
            </div>
            <div class="form-group col-6">
                <label for="cop"><strong>Certificate of Participation</strong></label>
                <input class="form-control btn-success" type="file" name="cop" id="cop" required>
            </div>
        </div>
        <a class="btn btn-outline-info pull-left btn-lg" data-toggle="tooltip" title="GO BACK" data-placement="right" href="approvals.php"><i class="fa fa-chevron-left"></i></a>
        <button class="btn btn-outline-success btn-lg pull-right" type="submit" name="send" value="Send">Send <i class="fa fa-send"></i></button>
    </form>
        </div>
    </div>
</body>
 <script src="../js/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/scripts.js"></script>
    <script>
        $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</html>
<?php } ?>